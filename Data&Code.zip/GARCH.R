# fit NNAR-GARCH model
require(forecast)
require(fGarch)

garch<-function(x){
        fit <- nnetar(x)
        res <- residuals(fit)
        res <- res[!is.na(res)]
        garchFit(data = res, trace = FALSE)
}