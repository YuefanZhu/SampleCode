# correlation analysis
from <- "4/10/12"
to <- "6/15/15"
len <- 800
N <- length(sec)
sec1List <- c()
sec2List <- c()
corList <- c()
for (i in 1 : (n - 1)) {
        for (j in (i + 1) : n) {
                sec1 <- sec[i]
                sec2 <- sec[j]
                date1 <- data[, sec1]
                date2 <- data[, sec2]
                close1 <- data[, which(colnames(data) == sec1) + 1]
                close2 <- data[, which(colnames(data) == sec2) + 1]
                names(close1) <- date1
                names(close2) <- date2
                if (sum(date1 == from) & sum(date1 == to) & sum(date2 == from) & sum(date2 == to)) {
                        period1 <- which(date1 == from) : which(date1 == to)
                        period2 <- which(date2 == from) : which(date2 == to)
                        S1 <- close1[period1]
                        S2 <- close2[period2]
                        logS1 <- log(S1)
                        logS2 <- log(S2)
                        commonDate <- intersect(names(S1), names(S2))
                        sec1List <- c(sec1List, sec1)
                        sec2List <- c(sec2List, sec2)
                        corList <- c(corList, cor(logS1[commonDate], logS2[commonDate]))
                }
        }
}
cortable <- data.frame(sec1List, sec2List, corList)
cortable <- cortable[order(cortable[,3], decreasing = T),]
write.csv(cortable, file = "correlation.csv")