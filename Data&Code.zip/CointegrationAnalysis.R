# choose sample period and pair 
from <- "4/10/12"
to <- "6/15/15"
#to <- "3/31/16"
SEC <- read.csv("c.csv", stringsAsFactors = FALSE)
SEC <- SEC[, c(3, 4)]
I <- 3
sec1 <- SEC[I, 1]
sec2 <- SEC[I, 2]
date1 <- data[, sec1]
date2 <- data[, sec2]
close1 <- data[, which(colnames(data) == sec1) + 1]
close2 <- data[, which(colnames(data) == sec2) + 1]
names(close1) <- date1
names(close2) <- date2
period1 <- which(date1 == from) : which(date1 == to)
period2 <- which(date2 == from) : which(date2 == to)
S1 <- close1[period1]
S2 <- close2[period2]
commonDate <- intersect(names(S1), names(S2))
n <- length(commonDate)
cat("Sample length: ", n)
S1 <- close1[commonDate]
S2 <- close2[commonDate]
logS1 <- log(S1)
logS2 <- log(S2)

# stationariness test
require(tseries)
adf.test(logS1)
adf.test(logS2)
adf.test(diff(logS1))
adf.test(diff(logS2))

# cointegration test
cm.fit <- lm(logS1 ~ logS2)
cm_epsilon <- residuals(cm.fit)
# adfTest <- adf.test(cm_epsilon)
# adfTest$p.value

# error correction model
ecm.fit <- lm(logS1[-1] ~ logS2[-1] + logS2[-n] + logS1[-n])
ecm_coeff <- ecm.fit$coefficients
beta <- (ecm_coeff[2] + ecm_coeff[3]) / (1 - ecm_coeff[4])
spread <- logS1 - beta * logS2
plot(spread, type = "l", xlab = "Time", ylab = "Spread", main = paste("MMM", "vs.", "ZBH"))

window <- 60
So <- 1.0
Sc <- 0
cost <- 0.002
backtest1 <- backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "naive")
backtest2 <- backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "ou")
backtest3 <- backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "garch")
plot(backtest1[[1]], type = "l", xlab = "Time", ylab = "Net Value", ylim = c(0.5, 5.5))
lines(backtest2[[2]], type = "l", col = "red")
lines(backtest3[[3]], type = "l", col = "blue")
lines(SP500[names(backtest1[[1]])] / SP500[names(backtest1[[1]])][1], type = "l", col = "green")
legend(0, 5, c("White Noise", "O-U", "NNAR-GARCH", "SP500"), cex = 0.5, fill = c("black", "red", "blue", "green"))
PerformanceMeasure(backtest1[[1]], backtest1[[2]], SP500)
PerformanceMeasure(backtest2[[2]], backtest2[[2]], SP500)
PerformanceMeasure(backtest3[[3]], backtest3[[2]], SP500)