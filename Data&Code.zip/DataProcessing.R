# load data
setwd("~/Desktop/Sheng's/Courses/2016Spring/IEORE4733/Final/Data")
data <- read.csv("SP500Components.csv", stringsAsFactors = FALSE)
sec <- colnames(data)[seq(1, ncol(data), 3)]
SP500 <- read.csv("SP500.csv", stringsAsFactors = FALSE)
date <- SP500[, 1]
SP500 <- SP500[, 2]
names(SP500) <- date