# optimize parameters
from <- "4/10/12"
to <- "6/15/15"
window <- 60
cost <- 0.002
Sos <- seq(1, 1.5, 0.1) # So candidates
Scs <- seq(0, 0.5, 0.1) # Sc candidates
par1List <- c()
par2List <- c()
sr1List <- c()
sr2List <- c()
sr3List <- c()
for (So in Sos) {
        for (Sc in Scs) {
                BackTest1 <- backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "naive")
                BackTest2 <- backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "ou")
                BackTest3 <- tryCatch(backtest(sec1, sec2, beta, from, to, window, So, Sc, cost, model = "garch"), error = function(e) {""})
                if (NetValue3 == "") {
                        next
                }
                sr1 <- PerformanceMeasure(BackTest1[[1]], BackTest1[[2]], SP500)[1]
                sr2 <- PerformanceMeasure(BackTest2[[1]], BackTest2[[2]], SP500)[1]
                sr3 <- PerformanceMeasure(BackTest3[[1]], BackTest3[[2]], SP500)[1]
                par1List <- c(par1List, So)
                par2List <- c(par2List, Sc)
                sr1List <- c(sr1List, sr1)
                sr2List <- c(sr2List, sr2)
                sr3List <- c(sr3List, sr3)
        }
}
SR <- data.frame(par1List, par2List, sr1List, sr2List, sr3List)