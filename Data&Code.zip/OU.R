# calculate likelihood function
# require("sde")
# ou.lik <- function(x) {
#         function(theta1, theta2, theta3) {
#                 n <- length(x)
#                 dt <- deltat(x)
#                 -sum(dcOU(x = x[2 : n], Dt = dt, x0 = x[1 : (n - 1)],
#                           theta = c(theta1, theta2, theta3), log = TRUE))
#         }
# }
# 
# # fit Ornstein-Uhlenbeck process by MLE
# ou <- function(x) {
#         ou.fit <- mle(ou.lik(x),
#                 start = list(theta1 = 0, theta2 = 0.5, theta3 = 0.2),
#                 method = "L-BFGS-B", lower = c(0, 1e-5, 1e-3), upper = c(1, 1, 1))
# }

ou <- function(x) {
        n <- length(x)
        Sx <- sum(x[-n])
        Sy <- sum(x[-1])
        Sxx <- sum(x[-n] ^ 2)
        Sxy <- sum(x[-n] * x[-1])
        Syy <- sum(x[-1] ^ 2)
        mu <- (Sy * Sxx - Sx * Sxy) / (n * (Sxx - Sxy) - (Sx ^ 2 - Sx * Sy))
        lambda <- -log((Sxy - mu * Sx - mu * Sy + n * mu ^ 2) / (Sxx - 2 * mu * Sx + n * mu ^ 2))
        alpha <- exp(-lambda)
        sigma_hat <- sqrt(1 / n * (Syy - 2 * alpha * Sxy + alpha ^ 2 * Sxx - 2 * mu * (1 - alpha) * (Sy - alpha * Sx) + n * mu ^ 2 * (1 - alpha) ^ 2))
        sigma <- sigma_hat * sqrt(2 * lambda / (1 - alpha ^ 2))
        return (c(mu, max(lambda, 0), sigma))
                       
}