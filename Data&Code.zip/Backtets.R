# calculte s_score
s_score <- function(x, model) {
        n <- length(x)
        if (model == "naive") {
                mu <- mean(x)
                sigma <- sd(x)
                (x[n] - mu) / sigma
        }
#         else if (model == "ou") {
#                 ou.fit <- ou(x)
#                 ou.coeff <- coef(ou.fit)
#                 names(ou.coeff) <- NULL
#                 lambda <- ou.coeff[2]
#                 mu <- ou.coeff[1] / ou.coeff[2]
#                 sigma <- ou.coeff[3]
#                 (x[n] - mu) / (sigma / sqrt(2 * lambda))
#         }
        else if (model == "ou") {
                ou.fit <- ou(x)
                mu <- ou.fit[1]
                lambda <- ou.fit[2]
                sigma <- ou.fit[3]
                (x[n] - mu) / (sigma / sqrt(2 * lambda))
        }
        else if (model == "garch") {
                garch.fit <- garch(x)
                mu <- mean(x)
                garch.sigma <- garch.fit@sigma.t
                sigma <- garch.sigma[length(garch.sigma)]
                (x[n] - mu) / sigma
        }
}
# s_score(spread, "naive")
# s_score(spread, "ou")
# s_score(spread, "garch")

# trading signals
# buy to open if s[i] < -So
# sell to open if s[i] > So
# close short position if s[i] < Sc
# close long position if s[i] > -Sc

# backtest
# IS: 4/10/12 - 6/15/15 800 trading days
# OS: 6/16/15 - 3/31/16 200 trading days
backtest <- function(sec1, sec2, beta, from, to, window, So, Sc, cost, model) {
        # get stock data during sample period
        date1 <- data[, sec1]
        date2 <- data[, sec2]
        close1 <- data[, which(colnames(data) == sec1) + 1]
        close2 <- data[, which(colnames(data) == sec2) + 1]
        names(close1) <- date1
        names(close2) <- date2
        period1 <- which(date1 == from) : which(date1 == to)
        period2 <- which(date2 == from) : which(date2 == to)
        S1 <- close1[period1]
        S2 <- close2[period2]
        commonDate <- intersect(names(S1), names(S2))
        n <- length(commonDate)
        S1 <- close1[commonDate]
        S2 <- close2[commonDate]
        logS1 <- log(S1)
        logS2 <- log(S2)
        spread <- logS1 - beta * logS2
        # backtest
        position <- rep(0, n)
        netValue <- rep(1, n)
        s <- rep(0, n)
        signal <- rep(0, n)
        names(position) <- commonDate
        names(netValue) <- commonDate
        names(s) <- commonDate
        names(signal) <- commonDate
        for (i in (window + 1) : n) {
                s[i] <- s_score(spread[(i - window) : (i - 1)], model)
                if (s[i] < -So & position[i - 1] == 0) { # buy to open
                        position[i] <- 1
                        netValue[i] <- netValue[i - 1] * (1 - cost)
                        signal[i] <- 1
                }
                else if (s[i] > So & position[i - 1] == 0) { # sell to open
                        position[i] <- -1
                        netValue[i] <- netValue[i - 1] * (1 - cost)
                        signal[i] <- 2
                }
                else if (s[i] < Sc & position[i - 1] == -1) { # close short position
                        position[i] <- 0
                        ret <- 1 - ((S1[i] - beta * S2[i]) / (S1[i - 1] - beta * S2[i - 1]) - 1)
                        netValue[i] <- netValue[i - 1] * ret * (1 - cost)
                        signal[i] <- 3
                }
                else if (s[i] > -Sc & position[i - 1] == 1) { # close long position
                        position[i] <- 0
                        ret <- 1 +  ((S1[i] - beta * S2[i]) / (S1[i - 1] - beta * S2[i - 1]) - 1)
                        netValue[i] <- netValue[i - 1] * ret * (1 - cost)
                        signal[i] <- 4
                }
                else { # no signals
                        position[i] <- position[i - 1]
                        if (position[i] == -1) {
                                ret <- 1 - ((S1[i] - beta * S2[i]) / (S1[i - 1] - beta * S2[i - 1]) - 1)
                                netValue[i] <- netValue[i - 1] * ret
                        }
                        else if (position[i] == 1) {
                                ret <- 1 + ((S1[i] - beta * S2[i]) / (S1[i - 1] - beta * S2[i - 1]) - 1)
                                netValue[i] <- netValue[i - 1] * ret
                        }
                        else {
                                netValue[i] <- netValue[i - 1]
                        }
                }
        }
        res <- list(netValue[-c(1 : window, n)], position[-c(1 : window, n)], signal[-c(1 : window, n)])
        return (res)
}

# performance measurements
PerformanceMeasure <- function(netValue, position, benchmark) {
        # extract common date
        commonDate <- intersect(names(netValue), names(benchmark))
        n <- length(commonDate)
        netValue <- netValue[commonDate]
        benchmark <- benchmark[commonDate]
        # annualized return
        annualizedReturn <- netValue[n] ^ (252 / n) - 1
        # annualized volatility
        annualizedVolatility <- sd(netValue[-1] / netValue[-n]) * sqrt(252)
        # Sharpe ratio
        rm <- (benchmark[n] / benchmark[1]) ^ (252 / n) - 1
        sharpeRatio <- (annualizedReturn - rm) / annualizedVolatility
        # max drawdown
        drawdown <- c()
        for(i in 1 : n) {
                drawdown[i] <- (netValue[i] - min(netValue[i : n])) / netValue[i]
        }
        maxDrawdown <- max(drawdown)
        # annulazied trade frequency
        tradeDays <- names(which(diff(position) != 0))
        totalTrades <- length(tradeDays)
        annualizedTradeFrequency <- totalTrades * 252 / n
        # win rate
        profits <- diff(netValue[tradeDays])
        profitTrades <- sum(profits > 0)
        winRate <- profitTrades /  totalTrades
        # average profit per trade
        avergeProfitPerTrade <- mean(profits)
        res <- c(sharpeRatio, annualizedReturn, maxDrawdown, annualizedVolatility, annualizedTradeFrequency, winRate, avergeProfitPerTrade)
        res <- round(res, 2)
        names(res) <- c("Sharpe Ratio", "Annualized Return", "Max Drawdown", "Annualized Volatility", "Annualized Trade Frequency", "Win Rate", "Averge Profit Per Trade")
        res
}